import { json } from "express";

// Export middleware
export default json();
