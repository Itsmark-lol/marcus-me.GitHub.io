declare type PWAProps = {
	title?: string;
	name?: string;
	description?: string;
}
